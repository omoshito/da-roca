// Sistema de Gerenciamento de Carrinho
class CarrinhoManager {
    constructor() {
        this.carrinho = this.carregarCarrinho();
        this.init();
    }

    init() {
        this.renderizarCarrinho();
        this.setupEventListeners();
        this.atualizarResumo();
    }

    // Carrega carrinho do localStorage
    carregarCarrinho() {
        const carrinho = localStorage.getItem('carrinho');
        return carrinho ? JSON.parse(carrinho) : [];
    }

    // Salva carrinho no localStorage
    salvarCarrinho() {
        localStorage.setItem('carrinho', JSON.stringify(this.carrinho));
    }

    // Renderiza lista de produtos
    renderizarCarrinho() {
        const container = document.getElementById('carrinho-items');
        if (!container) return;

        if (this.carrinho.length === 0) {
            container.innerHTML = `
                <div class="carrinho-vazio">
                    <i class='bx bx-cart-alt'></i>
                    <h3>Seu carrinho está vazio</h3>
                    <p>Adicione produtos para começar suas compras</p>
                    <a href="Catalogo.html" class="btn-ir-catalogo">
                        <i class='bx bx-shopping-bag'></i>
                        Ir para o Catálogo
                    </a>
                </div>
            `;
            return;
        }

        container.innerHTML = this.carrinho.map((item, index) => `
            <div class="carrinho-item" data-index="${index}">
                <div class="item-image">
                    <img src="${item.imagem || '../Imagens/default.svg'}" alt="${item.nome}">
                </div>
                <div class="item-info">
                    <h3>${item.nome}</h3>
                    <p class="item-descricao">${item.descricao || 'Produto fresco e natural'}</p>
                    <p class="item-preco">R$ ${this.formatarPreco(item.preco)}</p>
                </div>
                <div class="item-quantidade">
                    <button class="btn-quantidade" onclick="carrinhoManager.diminuirQuantidade(${index})">
                        <i class='bx bx-minus'></i>
                    </button>
                    <input type="number" value="${item.quantidade}" min="1" max="99" 
                           onchange="carrinhoManager.atualizarQuantidade(${index}, this.value)">
                    <button class="btn-quantidade" onclick="carrinhoManager.aumentarQuantidade(${index})">
                        <i class='bx bx-plus'></i>
                    </button>
                </div>
                <div class="item-total">
                    <p class="total-label">Total</p>
                    <p class="total-valor">R$ ${this.formatarPreco(item.preco * item.quantidade)}</p>
                </div>
                <button class="btn-remover" onclick="carrinhoManager.removerItem(${index})" title="Remover">
                    <i class='bx bx-trash'></i>
                </button>
            </div>
        `).join('');
    }

    // Aumentar quantidade
    aumentarQuantidade(index) {
        if (this.carrinho[index].quantidade < 99) {
            this.carrinho[index].quantidade++;
            this.salvarCarrinho();
            this.renderizarCarrinho();
            this.atualizarResumo();
        }
    }

    // Diminuir quantidade
    diminuirQuantidade(index) {
        if (this.carrinho[index].quantidade > 1) {
            this.carrinho[index].quantidade--;
            this.salvarCarrinho();
            this.renderizarCarrinho();
            this.atualizarResumo();
        }
    }

    // Atualizar quantidade
    atualizarQuantidade(index, valor) {
        const quantidade = parseInt(valor);
        if (quantidade > 0 && quantidade <= 99) {
            this.carrinho[index].quantidade = quantidade;
            this.salvarCarrinho();
            this.renderizarCarrinho();
            this.atualizarResumo();
        }
    }

    // Remover item
    removerItem(index) {
        if (confirm('Deseja remover este produto do carrinho?')) {
            this.carrinho.splice(index, 1);
            this.salvarCarrinho();
            this.renderizarCarrinho();
            this.atualizarResumo();
            this.mostrarNotificacao('Produto removido do carrinho');
        }
    }

    // Atualizar resumo
    atualizarResumo() {
        const totalItems = this.carrinho.reduce((acc, item) => acc + item.quantidade, 0);
        const subtotal = this.carrinho.reduce((acc, item) => acc + (item.preco * item.quantidade), 0);
        const frete = subtotal >= 100 ? 0 : 15;
        const total = subtotal + frete;

        document.getElementById('total-items').textContent = totalItems;
        document.getElementById('subtotal').textContent = `R$ ${this.formatarPreco(subtotal)}`;
        document.getElementById('total').textContent = `R$ ${this.formatarPreco(total)}`;

        const freteEl = document.getElementById('frete');
        if (frete === 0) {
            freteEl.textContent = 'GRÁTIS';
            freteEl.className = 'frete-gratis';
        } else {
            freteEl.textContent = `R$ ${this.formatarPreco(frete)}`;
            freteEl.className = '';
        }
    }

    // Setup event listeners
    setupEventListeners() {
        const btnFinalizar = document.getElementById('btn-finalizar');
        if (btnFinalizar) {
            btnFinalizar.addEventListener('click', () => this.finalizarCompra());
        }

        const btnAplicarCupom = document.getElementById('btn-aplicar-cupom');
        if (btnAplicarCupom) {
            btnAplicarCupom.addEventListener('click', () => this.aplicarCupom());
        }
    }

    // Finalizar compra
    finalizarCompra() {
        if (this.carrinho.length === 0) {
            alert('Seu carrinho está vazio!');
            return;
        }

        // Verifica se está logado
        const usuario = AuthAPI.obterSessao();
        if (!usuario) {
            alert('Faça login para continuar com a compra');
            window.location.href = 'Login.html';
            return;
        }

        // Vai para página de pagamento
        window.location.href = 'Pagamento.html';
    }

    // Aplicar cupom
    aplicarCupom() {
        const cupomInput = document.getElementById('cupom-input');
        const cupom = cupomInput.value.trim().toUpperCase();

        if (!cupom) {
            alert('Digite um código de cupom');
            return;
        }

        // Cupons de exemplo
        const cupons = {
            'BEMVINDO10': 0.10,
            'FRETE GRATIS': 0,
            'DESCONTO20': 0.20
        };

        if (cupons[cupom] !== undefined) {
            this.mostrarNotificacao('Cupom aplicado com sucesso!', 'success');
            cupomInput.value = '';
            // Aqui você aplicaria o desconto
        } else {
            this.mostrarNotificacao('Cupom inválido', 'error');
        }
    }

    // Formatar preço
    formatarPreco(valor) {
        return valor.toFixed(2).replace('.', ',');
    }

    // Mostrar notificação
    mostrarNotificacao(mensagem, tipo = 'info') {
        // Cria notificação temporária
        const notif = document.createElement('div');
        notif.className = `notificacao notif-${tipo}`;
        notif.textContent = mensagem;
        document.body.appendChild(notif);

        setTimeout(() => notif.classList.add('show'), 10);
        setTimeout(() => {
            notif.classList.remove('show');
            setTimeout(() => notif.remove(), 300);
        }, 3000);
    }
}

// Inicializa quando o DOM carregar
let carrinhoManager;
document.addEventListener('DOMContentLoaded', () => {
    carrinhoManager = new CarrinhoManager();
});
