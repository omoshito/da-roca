// Validação de senha no frontend
class SenhaValidator {
    static validarForca(senha) {
        const criterios = {
            minLength: senha.length >= 8,
            hasUppercase: /[A-Z]/.test(senha),
            hasLowercase: /[a-z]/.test(senha),
            hasNumbers: /\d/.test(senha),
            hasSpecial: /[!@#$%^&*(),.?":{}|<>]/.test(senha)
        };

        const forca = Object.values(criterios).filter(Boolean).length;
        
        return {
            criterios,
            forca,
            nivel: this.getNivelForca(forca),
            isValid: forca >= 4
        };
    }

    static getNivelForca(forca) {
        if (forca <= 1) return 'muito-fraca';
        if (forca <= 2) return 'fraca';
        if (forca <= 3) return 'media';
        if (forca <= 4) return 'forte';
        return 'muito-forte';
    }

    static mostrarFeedback(senha, elemento) {
        const validacao = this.validarForca(senha);
        const nivelElement = elemento.querySelector('.password-strength-bar');
        
        if (nivelElement) {
            nivelElement.className = `password-strength-bar ${validacao.nivel}`;
        }

        return validacao;
    }

    static getMessagensCriterios(criterios) {
        const mensagens = [];
        
        if (!criterios.minLength) mensagens.push('• Pelo menos 8 caracteres');
        if (!criterios.hasUppercase) mensagens.push('• Uma letra maiúscula');
        if (!criterios.hasLowercase) mensagens.push('• Uma letra minúscula');
        if (!criterios.hasNumbers) mensagens.push('• Um número');
        if (!criterios.hasSpecial) mensagens.push('• Um caractere especial');
        
        return mensagens;
    }
}

// Tornar disponível globalmente
window.SenhaValidator = SenhaValidator;
