// Função para aplicar máscara de CPF
function aplicarMascaraCPF(valor) {
    // Remove caracteres não numéricos
    valor = valor.replace(/\D/g, '');
    
    // Aplica a máscara XXX.XXX.XXX-XX
    if (valor.length <= 11) {
        valor = valor.replace(/(\d{3})(\d)/, '$1.$2');
        valor = valor.replace(/(\d{3})(\d)/, '$1.$2');
        valor = valor.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    }
    
    return valor;
}

// Função para aplicar máscara de CEP
function aplicarMascaraCEP(valor) {
    valor = valor.replace(/\D/g, '');
    if (valor.length <= 8) {
        valor = valor.replace(/(\d{5})(\d)/, '$1-$2');
    }
    return valor;
}

// Função para aplicar máscara de telefone
function aplicarMascaraTelefone(valor) {
    valor = valor.replace(/\D/g, '');
    if (valor.length <= 11) {
        if (valor.length <= 10) {
            // Telefone fixo: (XX) XXXX-XXXX
            valor = valor.replace(/(\d{2})(\d)/, '($1) $2');
            valor = valor.replace(/(\d{4})(\d)/, '$1-$2');
        } else {
            // Celular: (XX) XXXXX-XXXX
            valor = valor.replace(/(\d{2})(\d)/, '($1) $2');
            valor = valor.replace(/(\d{5})(\d)/, '$1-$2');
        }
    }
    return valor;
}

// Função para buscar endereço por CEP usando ViaCEP
async function buscarViaCEP(cepLimpo) {
    try {
        const url = `https://viacep.com.br/ws/${cepLimpo}/json/`;
        console.log('Tentando ViaCEP:', url);
        
        const response = await fetch(url, { timeout: 5000 });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.erro) {
            throw new Error('CEP não encontrado no ViaCEP');
        }
        
        console.log('✓ ViaCEP retornou:', data);
        return {
            logradouro: data.logradouro,
            bairro: data.bairro,
            localidade: data.localidade,
            uf: data.uf,
            complemento: data.complemento
        };
    } catch (error) {
        console.warn('ViaCEP falhou:', error.message);
        throw error;
    }
}

// Função para buscar endereço por CEP usando BrasilAPI (alternativa)
async function buscarBrasilAPI(cepLimpo) {
    try {
        const url = `https://brasilapi.com.br/api/cep/v1/${cepLimpo}`;
        console.log('Tentando BrasilAPI:', url);
        
        const response = await fetch(url, { timeout: 5000 });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const data = await response.json();
        
        console.log('✓ BrasilAPI retornou:', data);
        return {
            logradouro: data.street,
            bairro: data.neighborhood,
            localidade: data.city,
            uf: data.state,
            complemento: ''
        };
    } catch (error) {
        console.warn('BrasilAPI falhou:', error.message);
        throw error;
    }
}

// Função para buscar endereço por CEP usando API Correios (alternativa 2)
async function buscarAPICorreios(cepLimpo) {
    try {
        const url = `https://cdn.apicep.com/file/apicep/${cepLimpo}.json`;
        console.log('Tentando API CEP:', url);
        
        const response = await fetch(url, { timeout: 5000 });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const data = await response.json();
        
        console.log('✓ API CEP retornou:', data);
        return {
            logradouro: data.address,
            bairro: data.district,
            localidade: data.city,
            uf: data.state,
            complemento: ''
        };
    } catch (error) {
        console.warn('API CEP falhou:', error.message);
        throw error;
    }
}

// Função principal para buscar endereço por CEP (com múltiplas APIs)
async function buscarEnderecoPorCEP(cep) {
    const cepLimpo = cep.replace(/\D/g, '');
    
    console.log('🔍 Buscando CEP:', cepLimpo);
    
    if (cepLimpo.length !== 8) {
        console.log('❌ CEP com tamanho inválido:', cepLimpo.length);
        return null;
    }
    
    // Lista de APIs para tentar em ordem
    const apis = [
        { nome: 'ViaCEP', funcao: buscarViaCEP },
        { nome: 'BrasilAPI', funcao: buscarBrasilAPI },
        { nome: 'API CEP', funcao: buscarAPICorreios }
    ];
    
    // Tenta cada API até uma funcionar
    for (const api of apis) {
        try {
            console.log(`🌐 Tentando ${api.nome}...`);
            const resultado = await api.funcao(cepLimpo);
            
            if (resultado) {
                console.log(`✅ Sucesso com ${api.nome}!`);
                return resultado;
            }
        } catch (error) {
            console.log(`⚠️ ${api.nome} falhou, tentando próxima...`);
            continue;
        }
    }
    
    // Se todas falharam
    console.error('❌ Todas as APIs de CEP falharam');
    return null;
}

// Função para validar CPF usando o algoritmo padrão
function validarCPF(cpf) {
    // Remove caracteres não numéricos
    cpf = cpf.replace(/[^\d]/g, '');
    
    // Verifica se tem 11 dígitos
    if (cpf.length !== 11) {
        return false;
    }
    
    // Verifica se todos os dígitos são iguais (CPF inválido)
    if (/^(\d)\1{10}$/.test(cpf)) {
        return false;
    }
    
    // Valida primeiro dígito verificador
    let soma = 0;
    for (let i = 0; i < 9; i++) {
        soma += parseInt(cpf.charAt(i)) * (10 - i);
    }
    let resto = soma % 11;
    let digitoVerificador1 = resto < 2 ? 0 : 11 - resto;
    
    if (parseInt(cpf.charAt(9)) !== digitoVerificador1) {
        return false;
    }
    
    // Valida segundo dígito verificador
    soma = 0;
    for (let i = 0; i < 10; i++) {
        soma += parseInt(cpf.charAt(i)) * (11 - i);
    }
    resto = soma % 11;
    let digitoVerificador2 = resto < 2 ? 0 : 11 - resto;
    
    if (parseInt(cpf.charAt(10)) !== digitoVerificador2) {
        return false;
    }
    
    return true;
}

// Adiciona event listener para máscara de CPF quando o documento carregar
document.addEventListener('DOMContentLoaded', function() {
    const senhaInput = document.getElementById('senha');
    const confirmarSenhaInput = document.getElementById('confirmar-senha');
    const cpfInput = document.getElementById('cpf');
    const cepInput = document.getElementById('cep');
    const telefoneInput = document.getElementById('telefone');
    
    // Validação de senha em tempo real
    if (senhaInput) {
        senhaInput.addEventListener('input', function() {
            const senha = this.value;
            const inputGroup = this.closest('.input-group');
            const strengthContainer = inputGroup.querySelector('.password-strength');
            
            if (senha.length > 0) {
                const validacao = SenhaValidator.mostrarFeedback(senha, inputGroup);
                
                // Mostra critérios se não existir ainda
                let criteriaDiv = inputGroup.querySelector('.password-criteria');
                if (!criteriaDiv && senha.length > 0) {
                    criteriaDiv = document.createElement('div');
                    criteriaDiv.className = 'password-criteria';
                    criteriaDiv.innerHTML = `
                        <ul>
                            <li class="${validacao.criterios.minLength ? 'valid' : 'invalid'}">Pelo menos 8 caracteres</li>
                            <li class="${validacao.criterios.hasUppercase ? 'valid' : 'invalid'}">Uma letra maiúscula</li>
                            <li class="${validacao.criterios.hasLowercase ? 'valid' : 'invalid'}">Uma letra minúscula</li>
                            <li class="${validacao.criterios.hasNumbers ? 'valid' : 'invalid'}">Um número</li>
                            <li class="${validacao.criterios.hasSpecial ? 'valid' : 'invalid'}">Um caractere especial</li>
                        </ul>
                    `;
                    strengthContainer.after(criteriaDiv);
                } else if (criteriaDiv) {
                    // Atualiza critérios existentes
                    const items = criteriaDiv.querySelectorAll('li');
                    const criterios = Object.values(validacao.criterios);
                    items.forEach((item, index) => {
                        item.className = criterios[index] ? 'valid' : 'invalid';
                    });
                }
                
                // Atualiza classe do input group
                inputGroup.className = `input-group ${validacao.isValid ? 'success' : 'error'}`;
            }
        });
    }
    
    // Validação de confirmação de senha
    if (confirmarSenhaInput) {
        confirmarSenhaInput.addEventListener('input', function() {
            const senha = senhaInput.value;
            const confirmacao = this.value;
            const inputGroup = this.closest('.input-group');
            const errorMsg = inputGroup.querySelector('.error-message');
            
            if (confirmacao.length > 0) {
                if (senha === confirmacao) {
                    inputGroup.className = 'input-group success';
                    errorMsg.textContent = '';
                    errorMsg.className = 'error-message';
                } else {
                    inputGroup.className = 'input-group error';
                    errorMsg.textContent = 'Senhas não coincidem';
                    errorMsg.className = 'error-message visible';
                }
            }
        });
    }
    
    // Máscara de CPF
    if (cpfInput) {
        cpfInput.addEventListener('input', function() {
            this.value = aplicarMascaraCPF(this.value);
        });
        
        cpfInput.addEventListener('blur', function() {
            const cpf = this.value;
            const inputGroup = this.closest('.input-group');
            const errorMsg = inputGroup.querySelector('.error-message');
            
            if (cpf.length > 0) {
                if (validarCPF(cpf)) {
                    inputGroup.className = 'input-group success';
                    errorMsg.textContent = '';
                    errorMsg.className = 'error-message';
                } else {
                    inputGroup.className = 'input-group error';
                    errorMsg.textContent = 'CPF inválido';
                    errorMsg.className = 'error-message visible';
                }
            }
        });
    }

    // Máscara de telefone
    if (telefoneInput) {
        telefoneInput.addEventListener('input', function() {
            this.value = aplicarMascaraTelefone(this.value);
        });
    }
    
    // Máscara e busca de endereço por CEP
    if (cepInput) {
        cepInput.addEventListener('input', function() {
            const valorAnterior = this.value;
            this.value = aplicarMascaraCEP(this.value);
            
            // Remove mensagem de erro durante digitação
            const inputGroup = this.closest('.input-group');
            const errorMsg = inputGroup.querySelector('.error-message');
            if (this.value.length < 9) { // 9 = 8 dígitos + 1 hífen
                inputGroup.className = 'input-group';
                errorMsg.textContent = '';
                errorMsg.className = 'error-message';
            }
        });
        
        cepInput.addEventListener('blur', async function() {
            const cep = this.value;
            const inputGroup = this.closest('.input-group');
            const errorMsg = inputGroup.querySelector('.error-message');
            
            // Se o campo estiver vazio, não faz nada (campo opcional)
            if (cep.length === 0) {
                inputGroup.className = 'input-group';
                errorMsg.textContent = '';
                errorMsg.className = 'error-message';
                return;
            }
            
            // Verifica se tem o tamanho correto
            const cepLimpo = cep.replace(/\D/g, '');
            if (cepLimpo.length !== 8) {
                inputGroup.className = 'input-group error';
                errorMsg.textContent = 'CEP incompleto. Digite 8 dígitos.';
                errorMsg.className = 'error-message visible';
                return;
            }
            
            // Mostra loading
            errorMsg.textContent = 'Buscando...';
            errorMsg.className = 'error-message visible';
            inputGroup.className = 'input-group';
            
            // Busca endereço pelo CEP
            const endereco = await buscarEnderecoPorCEP(cep);
            
            if (endereco) {
                // Preenche os campos de endereço automaticamente
                const logradouroInput = document.getElementById('logradouro');
                const bairroInput = document.getElementById('bairro');
                const cidadeInput = document.getElementById('cidade');
                const estadoInput = document.getElementById('estado');
                const complementoInput = document.getElementById('complemento');
                
                // Preenche os campos
                logradouroInput.value = endereco.logradouro || '';
                bairroInput.value = endereco.bairro || '';
                cidadeInput.value = endereco.localidade || '';
                estadoInput.value = endereco.uf || '';
                
                // Preenche complemento se houver (e se estiver vazio)
                if (endereco.complemento && !complementoInput.value) {
                    complementoInput.value = endereco.complemento;
                }
                
                // Adiciona feedback visual nos campos preenchidos
                [logradouroInput, bairroInput, cidadeInput].forEach(input => {
                    if (input && input.value) {
                        const group = input.closest('.input-group');
                        if (group) {
                            group.classList.add('success');
                            // Adiciona animação de preenchimento
                            input.style.transition = 'all 0.3s ease';
                            input.style.backgroundColor = '#e8f5e9';
                            setTimeout(() => {
                                input.style.backgroundColor = '';
                            }, 1000);
                        }
                    }
                });
                
                // Marca o campo de estado como preenchido também
                if (estadoInput && estadoInput.value) {
                    const group = estadoInput.closest('.input-group');
                    if (group) {
                        group.classList.add('success');
                        estadoInput.style.transition = 'all 0.3s ease';
                        estadoInput.style.backgroundColor = '#e8f5e9';
                        setTimeout(() => {
                            estadoInput.style.backgroundColor = '';
                        }, 1000);
                    }
                }
                
                inputGroup.className = 'input-group success';
                errorMsg.textContent = '✓ Endereço encontrado e preenchido automaticamente!';
                errorMsg.className = 'error-message visible';
                errorMsg.style.color = 'green';
                
                // Foca no campo número (próximo campo a ser preenchido)
                const numeroInput = document.getElementById('numero');
                if (numeroInput) {
                    setTimeout(() => {
                        numeroInput.focus();
                    }, 500);
                }
                
                // Remove a mensagem depois de 3 segundos
                setTimeout(() => {
                    errorMsg.textContent = '';
                    errorMsg.className = 'error-message';
                    errorMsg.style.color = '';
                }, 3000);
            } else {
                inputGroup.className = 'input-group error';
                errorMsg.textContent = 'CEP não encontrado. Verifique o número digitado ou preencha manualmente.';
                errorMsg.className = 'error-message visible';
                errorMsg.style.color = '';
            }
        });
    }
});

async function cadastrarCliente() {
    const nome = document.getElementById('nome').value.trim();
    const email = document.getElementById('email').value.trim();
    const telefone = document.getElementById('telefone').value.trim();
    const cpf = document.getElementById('cpf').value.trim();
    const senha = document.getElementById('senha').value;
    const confsenha = document.getElementById('confirmar-senha').value;
    
    // Dados de endereço
    const cep = document.getElementById('cep').value.trim();
    const logradouro = document.getElementById('logradouro').value.trim();
    const numero = document.getElementById('numero').value.trim();
    const complemento = document.getElementById('complemento').value.trim();
    const bairro = document.getElementById('bairro').value.trim();
    const cidade = document.getElementById('cidade').value.trim();
    const estado = document.getElementById('estado').value.trim();
    const dataNascimento = document.getElementById('idade').value;

    // Valida campos obrigatórios
    const camposObrigatorios = [
        { nome: 'Nome', valor: nome },
        { nome: 'E-mail', valor: email },
        { nome: 'Telefone', valor: telefone },
        { nome: 'CPF', valor: cpf },
        { nome: 'Senha', valor: senha },
        { nome: 'Confirmar senha', valor: confsenha },
        { nome: 'Logradouro', valor: logradouro },
        { nome: 'Número', valor: numero },
        { nome: 'Bairro', valor: bairro },
        { nome: 'Cidade', valor: cidade },
        { nome: 'Estado', valor: estado },
        { nome: 'Data de nascimento', valor: dataNascimento }
    ];

    const faltando = camposObrigatorios.find(c => !c.valor);
    if (faltando) {
        alert(`Por favor, preencha o campo: ${faltando.nome}`);
        return;
    }

    // Validação de senha com SenhaValidator
    const validacaoSenha = SenhaValidator.validarForca(senha);
    if (!validacaoSenha.isValid) {
        const mensagens = SenhaValidator.getMessagensCriterios(validacaoSenha.criterios);
        alert('A senha não atende aos critérios de segurança:\n' + mensagens.join('\n'));
        return;
    }

    if (senha !== confsenha) {
        alert('As senhas não coincidem.');
        return;
    }

    // Validação de CPF
    if (!validarCPF(cpf)) {
        alert('CPF inválido. Por favor, verifique o número digitado.');
        return;
    }

    // Validação de CEP (se preenchido)
    if (cep && cep.length > 0) {
        const cepLimpo = cep.replace(/[^\d]/g, '');
        if (cepLimpo.length !== 8) {
            alert('CEP inválido. Por favor, verifique o número digitado.');
            return;
        }
    }

    // Remove formatação do CPF, telefone e CEP para enviar apenas números
    const cpfLimpo = cpf.replace(/[^\d]/g, '');
    const telefoneLimpo = telefone.replace(/[^\d]/g, '');
    const cepLimpo = cep ? cep.replace(/[^\d]/g, '') : '';

    // Dados completos do cliente incluindo endereço
    const clienteData = {
        cpf: cpfLimpo,
        nome: nome,
        telefone: telefoneLimpo,
        email: email,
        senha: senha,
        dataNascimento: dataNascimento,
        cep: cepLimpo || null,
        logradouro: logradouro,
        numero: numero,
        complemento: complemento || null,
        bairro: bairro,
        cidade: cidade,
        estado: estado
    };

    console.log('Dados a serem enviados:', clienteData); // Log para debug

    try {
        const botao = document.querySelector('.btn-primary');
        if (botao) {
            botao.textContent = 'Enviando...';
            botao.disabled = true;
        }

        const response = await fetch('http://localhost:8090/daroca/clientes', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(clienteData)
        });
        
        const data = await response.json();
        
        console.log('Resposta do servidor:', data); // Log para debug
        
        if (!response.ok) {
            throw new Error(data.mensagem || data.erro || 'Erro ao cadastrar cliente');
        }

        if (data.sucesso) {
            alert('Cadastro realizado com sucesso! Você será redirecionado para o login.');
            window.location.href = 'Login.html';
        } else {
            throw new Error(data.mensagem || 'Erro ao cadastrar cliente');
        }
        
        return data;
    } catch (error) {
        console.error('Erro ao cadastrar cliente:', error);
        alert(`Erro ao cadastrar: ${error.message}`);
        throw error;
    } finally {
        const botao = document.querySelector('.btn-primary');
        if (botao) {
            botao.textContent = 'Criar conta';
            botao.disabled = false;
        }
    }
}