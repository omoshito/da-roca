// catalogo.js - Gerenciamento do catálogo de produtos

// Produtos mock como fallback caso a API falhe
const mockProducts = [
    // Frutas
    { id: 1, nome: "Alface Manteiga", descricao: "Alface fresca e orgânica, ideal para saladas", preco: 3.50, imagem: "../Imagens/Alface Manteiga.webp", categoria: "verduras" },
    { id: 2, nome: "Banana Nanica", descricao: "Bananas doces e nutritivas, ricas em potássio", preco: 4.20, imagem: "../Imagens/Banana Nanica.jpg", categoria: "frutas" },
    { id: 3, nome: "Cenoura Orgânica", descricao: "Cenouras orgânicas crocantes e saborosas", preco: 2.80, imagem: "../Imagens/cenoura.avif", categoria: "vegetais" },
    { id: 4, nome: "Feijão Preto", descricao: "Feijão preto de alta qualidade, rico em proteínas", preco: 7.50, imagem: "../Imagens/Feijão Preto.webp", categoria: "graos" },
    { id: 5, nome: "Mix de Berries", descricao: "Mistura de mirtilo e framboesa, antioxidantes naturais", preco: 12.50, imagem: "../Imagens/Mirtilo e Framboesa.avif", categoria: "frutas" },
    { id: 6, nome: "Morango Orgânico", descricao: "Morangos orgânicos doces e suculentos", preco: 8.90, imagem: "../Imagens/Morango Orgânico.webp", categoria: "frutas" },
    { id: 7, nome: "Queijo Minas", descricao: "Queijo minas fresco tradicional, cremoso", preco: 15.80, imagem: "../Imagens/Queijo Minas.jpg", categoria: "laticinios" },
    { id: 8, nome: "Tomate Orgânico", descricao: "Tomates orgânicos frescos e saborosos", preco: 5.60, imagem: "../Imagens/Tomate Orgânico.jpg", categoria: "vegetais" },
    
    // Adicionando mais verduras
    { id: 9, nome: "Couve Manteiga", descricao: "Couve fresca, rica em vitaminas e minerais", preco: 2.50, imagem: "../Imagens/default.png", categoria: "verduras" },
    { id: 10, nome: "Espinafre", descricao: "Espinafre fresco, fonte de ferro e ácido fólico", preco: 3.20, imagem: "../Imagens/default.png", categoria: "verduras" },
    { id: 11, nome: "Rúcula", descricao: "Rúcula aromática, perfeita para saladas gourmet", preco: 4.50, imagem: "../Imagens/default.png", categoria: "verduras" },
    
    // Mais vegetais 
    { id: 12, nome: "Abobrinha", descricao: "Abobrinha fresca, versátil para diversos pratos", preco: 3.80, imagem: "../Imagens/default.png", categoria: "vegetais" },
    { id: 13, nome: "Berinjela", descricao: "Berinjela roxa, ideal para refogados e assados", preco: 4.90, imagem: "../Imagens/default.png", categoria: "vegetais" }
];

let allProducts = [];
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Inicialização
(async function init() {
    console.log('🚀 Inicializando catálogo...');
    
    try {
        // Tenta carregar da API primeiro
        if (typeof ProductAPI !== 'undefined') {
            console.log('📡 Tentando carregar produtos da API...');
            allProducts = await ProductAPI.getProducts();
            console.log('✅ Produtos carregados da API:', allProducts.length);
        } else {
            console.warn('⚠️ ProductAPI não encontrado, usando dados mock');
        }
        
        // Se a API falhar ou retornar vazio, usa mock
        if (!allProducts || allProducts.length === 0) {
            console.warn('⚠️ API não retornou produtos, usando dados mock');
            allProducts = mockProducts;
            console.log('📦 Usando produtos mock:', allProducts.length);
        }
        
        console.log('🎯 Produtos finais para renderizar:', allProducts);
    } catch (error) {
        console.error('❌ Erro ao carregar produtos da API:', error);
        allProducts = mockProducts;
        console.log('📦 Fallback para produtos mock:', allProducts.length);
    }

    renderProducts(allProducts);
    setupEventListeners();
    updateCartDisplay();
    
    console.log('✅ Catálogo inicializado com sucesso!');
})();

// Configurar event listeners
function setupEventListeners() {
    // Filtros de categoria
    const filterButtons = document.querySelectorAll('.filter-btn');
    filterButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            filterButtons.forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            
            const category = e.target.dataset.filter;
            filterAndSearchProducts(category);
        });
    });

    // Pesquisa
    const searchInput = document.getElementById('search-product');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const activeFilter = document.querySelector('.filter-btn.active').dataset.filter;
            filterAndSearchProducts(activeFilter, e.target.value);
        });
    }

    // Carrinho
    const cartBtn = document.getElementById('cart-btn');
    const cartModal = document.getElementById('cart-modal');
    const closeCart = document.getElementById('close-cart');

    if (cartBtn) {
        cartBtn.addEventListener('click', () => {
            renderCartItems();
            cartModal.style.display = 'flex';
        });
    }

    if (closeCart) {
        closeCart.addEventListener('click', () => {
            cartModal.style.display = 'none';
        });
    }

    if (cartModal) {
        cartModal.addEventListener('click', (e) => {
            if (e.target === cartModal) {
                cartModal.style.display = 'none';
            }
        });
    }

    // Checkout
    const checkoutBtn = document.getElementById('checkout-btn');
    if (checkoutBtn) {
        checkoutBtn.addEventListener('click', () => {
            if (cart.length === 0) {
                alert('Seu carrinho está vazio!');
                return;
            }
            alert('Funcionalidade de checkout em desenvolvimento!');
        });
    }
}

// Renderizar produtos organizados por categoria
function renderProducts(filteredProducts) {
    const productList = document.getElementById('product-list');
    
    if (!productList) {
        console.error('Elemento product-list não encontrado');
        return;
    }

    if (filteredProducts.length === 0) {
        productList.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 40px;">
                <p style="font-size: 1.2rem; color: var(--text-light);">Nenhum produto encontrado</p>
            </div>
        `;
        return;
    }

    // Agrupar produtos por categoria_id ou categoria
    const produtosPorCategoria = {};
    
    filteredProducts.forEach(product => {
        const categoria = product.categoria_id || product.categoria || 'outros';
        if (!produtosPorCategoria[categoria]) {
            produtosPorCategoria[categoria] = [];
        }
        produtosPorCategoria[categoria].push(product);
    });

    // Ordenar categorias alfabeticamente
    const categoriasOrdenadas = Object.keys(produtosPorCategoria).sort();

    // Renderizar produtos agrupados por categoria
    productList.innerHTML = categoriasOrdenadas.map(categoria => {
        const produtos = produtosPorCategoria[categoria];
        const categoriaNome = categoria.charAt(0).toUpperCase() + categoria.slice(1);
        
        const produtosHTML = produtos.map(product => {
            // Garante que o preço seja um número válido
            const preco = product.preco || parseFloat(product.valor?.replace('R$', '').replace(',', '.')) || 0;
            const precoFormatado = `R$ ${preco.toFixed(2).replace('.', ',')}`;
            
            // Capitaliza o nome da categoria
            const categoriaFormatada = product.categoria?.charAt(0).toUpperCase() + product.categoria?.slice(1) || categoriaNome;
        
            return `
            <div class="product-card" data-category="${product.categoria}">
                <div class="product-image-container" onclick="goToProductDetails(${product.id})">
                    <img src="${product.imagem}" alt="${product.nome}" class="product-image" 
                         onerror="this.src='../Imagens/default.png'">
                    <span class="product-category-badge">${categoriaFormatada}</span>
                </div>
                <div class="product-info">
                    <h3 class="product-name" title="${product.nome}">${product.nome}</h3>
                    <p class="product-description" title="${product.descricao}">${product.descricao || 'Produto fresco e de qualidade'}</p>
                    <div class="product-footer">
                        <span class="product-price">${precoFormatado}</span>
                        <button class="add-to-cart-btn" onclick="addToCart(${product.id})" title="Adicionar ao carrinho">
                            <i class='bx bx-cart-add'></i>
                            Adicionar
                        </button>
                    </div>
                </div>
            </div>`;
        }).join('');
        
        return `
            <div style="grid-column: 1/-1; margin: 20px 0 10px 0;">
                <h2 style="color: var(--primary-color); font-size: 1.5rem; border-bottom: 2px solid var(--primary-color); padding-bottom: 10px;">
                    ${categoriaNome}
                </h2>
            </div>
            ${produtosHTML}
        `;
    }).join('');
}

// Filtrar e pesquisar produtos
function filterAndSearchProducts(category, searchTerm = '') {
    let filtered = allProducts;

    // Filtro por categoria
    if (category !== 'all') {
        filtered = filtered.filter(p => p.categoria === category);
    }

    // Filtro por pesquisa
    if (searchTerm) {
        filtered = filtered.filter(p =>
            p.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
            p.descricao.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }

    renderProducts(filtered);
}

// Adicionar ao carrinho
function addToCart(productId) {
    const product = allProducts.find(p => p.id === productId);
    if (!product) return;

    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantidade += 1;
    } else {
        cart.push({
            id: product.id,
            nome: product.nome,
            preco: Number(product.preco),
            imagem: product.imagem,
            quantidade: 1
        });
    }

    saveCart();
    updateCartDisplay();
    showCartNotification(`${product.nome} adicionado ao carrinho!`);
}

// Remover do carrinho
function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    saveCart();
    updateCartDisplay();
    renderCartItems();
}

// Atualizar quantidade
function updateCartQuantity(productId, newQuantity) {
    const item = cart.find(item => item.id === productId);
    if (item) {
        if (newQuantity <= 0) {
            removeFromCart(productId);
        } else {
            item.quantidade = newQuantity;
            saveCart();
            updateCartDisplay();
            renderCartItems();
        }
    }
}

// Salvar carrinho
function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

// Atualizar display do carrinho
function updateCartDisplay() {
    const cartCount = document.getElementById('cart-count');
    const totalItems = cart.reduce((sum, item) => sum + item.quantidade, 0);

    if (cartCount) {
        if (totalItems > 0) {
            cartCount.textContent = totalItems;
            cartCount.style.display = 'flex';
        } else {
            cartCount.style.display = 'none';
        }
    }
}

// Calcular total
function calculateCartTotal() {
    return cart.reduce((total, item) => total + (item.preco * item.quantidade), 0);
}

// Renderizar itens do carrinho
function renderCartItems() {
    const cartItems = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');

    if (!cartItems || !cartTotal) return;

    if (cart.length === 0) {
        cartItems.innerHTML = `
            <div class="empty-cart">
                <i class='bx bx-cart' style="font-size: 3rem; color: var(--primary-color);"></i>
                <p>Seu carrinho está vazio</p>
            </div>
        `;
    } else {
        cartItems.innerHTML = cart.map(item => `
            <div class="cart-item">
                <img src="${item.imagem}" alt="${item.nome}">
                <div class="cart-item-info">
                    <h4>${item.nome}</h4>
                    <p class="cart-item-price">R$ ${item.preco.toFixed(2).replace('.', ',')}</p>
                </div>
                <div class="cart-item-controls">
                    <button class="quantity-btn" onclick="updateCartQuantity(${item.id}, ${item.quantidade - 1})">-</button>
                    <span class="quantity">${item.quantidade}</span>
                    <button class="quantity-btn" onclick="updateCartQuantity(${item.id}, ${item.quantidade + 1})">+</button>
                    <button class="remove-item" onclick="removeFromCart(${item.id})">
                        <i class='bx bx-trash'></i>
                    </button>
                </div>
            </div>
        `).join('');
    }

    cartTotal.textContent = calculateCartTotal().toFixed(2).replace('.', ',');
}

// Ir para detalhes do produto
function goToProductDetails(productId) {
    window.location.href = `Produto_detalhes.html?id=${productId}`;
}

// Mostrar notificação
function showCartNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'cart-notification show';
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 3000);
}