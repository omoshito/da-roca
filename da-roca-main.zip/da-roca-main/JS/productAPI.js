// API Real para produtos conectada ao backend
class ProductAPI {
    static get API_URL() {
        return window.CONFIG?.API_URL || 'http://localhost:8090/daroca';
    }

    static async getProducts() {
        try {
            const response = await fetch(`${this.API_URL}/produtos`);
            if (!response.ok) {
                throw new Error('Erro ao buscar produtos');
            }
            const data = await response.json();
            
            // A API retorna um array ou objeto com array na propriedade 'value'
            const produtos = Array.isArray(data) ? data : (data.value || []);
            
            // Formata os produtos para manter compatibilidade com o frontend
            return produtos.map(produto => ({
                id: produto.id,
                nome: produto.nome,
                descricao: produto.descricao || '',
                valor: `R$ ${parseFloat(produto.valor).toFixed(2).replace('.', ',')}`,
                preco: parseFloat(produto.valor) || 0,
                imagem: produto.imagem || '../Imagens/default.png',
                categoria: this.getCategoryName(produto.categoria_id),
                estoque: produto.estoque || 10 // Default stock
            }));
        } catch (error) {
            console.error('Erro ao buscar produtos:', error);
            // Retorna array vazio em caso de erro
            return [];
        }
    }

    // Converte ID de categoria para nome
    static getCategoryName(categoriaId) {
        const categorias = {
            1: 'frutas',
            2: 'vegetais', 
            3: 'verduras',
            4: 'graos',
            5: 'laticinios'
        };
        return categorias[categoriaId] || 'outros';
    }

    static async searchProducts(query) {
        const products = await this.getProducts();
        return products.filter(product =>
            product.nome.toLowerCase().includes(query.toLowerCase()) ||
            product.descricao.toLowerCase().includes(query.toLowerCase())
        );
    }

    static async getProductsByCategory(category) {
        const products = await this.getProducts();
        if (category === 'all') return products;
        return products.filter(product => product.categoria === category);
    }
}

// Exporta para uso em outros módulos (se necessário)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ProductAPI;
}