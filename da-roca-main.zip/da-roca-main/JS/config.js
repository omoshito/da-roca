// Configurações globais da aplicação
const CONFIG = {
    API_URL: 'http://localhost:8090/daroca',
    API_BASE: 'http://localhost:8090'
};

// Torna disponível globalmente
window.CONFIG = CONFIG;
