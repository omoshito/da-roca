// Sistema de gerenciamento de navegação com autenticação
class NavigationManager {
    static init() {
        this.updateNavigation();
        this.setupDropdown();
    }

    // Atualiza a navegação baseado no estado de login
    static updateNavigation() {
        const usuario = AuthAPI.obterSessao();
        const navMenu = document.querySelector('.nav-menu');
        
        if (!navMenu) return;

        // Remove links de login e cadastro se existirem
        const loginLink = navMenu.querySelector('a[href="Login.html"]');
        const cadastroLink = navMenu.querySelector('a[href="Cadastro.html"]');
        
        if (usuario && usuario.cliente) {
            // Usuário logado - mostra perfil
            if (loginLink) loginLink.parentElement.remove();
            if (cadastroLink) cadastroLink.parentElement.remove();
            
            // Adiciona dropdown de perfil se não existir
            if (!navMenu.querySelector('.user-profile-dropdown')) {
                this.addProfileDropdown(navMenu, usuario.cliente);
            }
        } else {
            // Usuário não logado - mostra login e cadastro
            const profileDropdown = navMenu.querySelector('.user-profile-dropdown');
            if (profileDropdown) {
                profileDropdown.remove();
            }
            
            // Adiciona links de cadastro e login se não existirem
            if (!cadastroLink) {
                const cadastroLi = document.createElement('li');
                cadastroLi.innerHTML = '<a href="Cadastro.html">Cadastro</a>';
                navMenu.appendChild(cadastroLi);
            }
            
            if (!loginLink) {
                const loginLi = document.createElement('li');
                loginLi.innerHTML = '<a href="Login.html" class="btn-login">Login</a>';
                navMenu.appendChild(loginLi);
            }
        }
    }

    // Adiciona dropdown de perfil
    static addProfileDropdown(navMenu, cliente) {
        const profileLi = document.createElement('li');
        profileLi.className = 'user-profile-dropdown';
        
        const primeiroNome = cliente.Nome ? cliente.Nome.split(' ')[0] : 'Usuário';
        
        profileLi.innerHTML = `
            <div class="profile-trigger">
                <div class="profile-avatar">
                    <i class='bx bx-user'></i>
                </div>
                <span class="profile-name">${primeiroNome}</span>
                <i class='bx bx-chevron-down'></i>
            </div>
            <div class="profile-dropdown-menu">
                <div class="profile-header">
                    <div class="profile-avatar-large">
                        <i class='bx bx-user'></i>
                    </div>
                    <div class="profile-info">
                        <h4>${cliente.Nome || 'Usuário'}</h4>
                        <p>${cliente.Email || ''}</p>
                    </div>
                </div>
                <ul class="profile-menu-items">
                    <li>
                        <a href="Perfil.html">
                            <i class='bx bx-user-circle'></i>
                            <span>Meu Perfil</span>
                        </a>
                    </li>
                    <li>
                        <a href="Pedidos.html">
                            <i class='bx bx-shopping-bag'></i>
                            <span>Meus Pedidos</span>
                        </a>
                    </li>
                    <li>
                        <a href="Carrinho.html">
                            <i class='bx bx-cart'></i>
                            <span>Carrinho</span>
                        </a>
                    </li>
                    <li>
                        <a href="Configuracoes.html">
                            <i class='bx bx-cog'></i>
                            <span>Configurações</span>
                        </a>
                    </li>
                    <li class="divider"></li>
                    <li>
                        <a href="#" id="logout-btn">
                            <i class='bx bx-log-out'></i>
                            <span>Sair</span>
                        </a>
                    </li>
                </ul>
            </div>
        `;
        
        navMenu.appendChild(profileLi);
        
        // Adiciona evento de logout
        const logoutBtn = profileLi.querySelector('#logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.logout();
            });
        }
    }

    // Configura funcionalidade do dropdown
    static setupDropdown() {
        document.addEventListener('click', (e) => {
            const dropdown = document.querySelector('.user-profile-dropdown');
            if (!dropdown) return;

            const trigger = dropdown.querySelector('.profile-trigger');
            const menu = dropdown.querySelector('.profile-dropdown-menu');

            if (trigger && trigger.contains(e.target)) {
                // Toggle dropdown
                dropdown.classList.toggle('active');
            } else if (!dropdown.contains(e.target)) {
                // Fecha dropdown se clicar fora
                dropdown.classList.remove('active');
            }
        });
    }

    // Função de logout
    static logout() {
        if (confirm('Tem certeza que deseja sair?')) {
            AuthAPI.limparSessao();
            alert('Logout realizado com sucesso!');
            window.location.href = 'Pagina_inicio.html';
        }
    }
}

// Inicializa quando o DOM carregar
document.addEventListener('DOMContentLoaded', () => {
    NavigationManager.init();
});
