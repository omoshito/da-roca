const bcrypt = require('bcrypt');

// Middleware para criptografar senhas
const hashPassword = async (senha) => {
    try {
        const saltRounds = 10;
        return await bcrypt.hash(senha, saltRounds);
    } catch (error) {
        throw new Error('Erro ao criptografar senha');
    }
};

// Middleware para verificar senhas
const verifyPassword = async (senha, hash) => {
    try {
        return await bcrypt.compare(senha, hash);
    } catch (error) {
        throw new Error('Erro ao verificar senha');
    }
};

// Validação de força da senha
const validarSenha = (senha) => {
    const minLength = 8;
    const hasUppercase = /[A-Z]/.test(senha);
    const hasLowercase = /[a-z]/.test(senha);
    const hasNumbers = /\d/.test(senha);
    const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(senha);
    
    const errors = [];
    
    if (senha.length < minLength) {
        errors.push(`Senha deve ter pelo menos ${minLength} caracteres`);
    }
    if (!hasUppercase) {
        errors.push('Senha deve conter pelo menos uma letra maiúscula');
    }
    if (!hasLowercase) {
        errors.push('Senha deve conter pelo menos uma letra minúscula');
    }
    if (!hasNumbers) {
        errors.push('Senha deve conter pelo menos um número');
    }
    if (!hasSpecial) {
        errors.push('Senha deve conter pelo menos um caractere especial');
    }
    
    return {
        isValid: errors.length === 0,
        errors: errors
    };
};

module.exports = { hashPassword, verifyPassword, validarSenha };
