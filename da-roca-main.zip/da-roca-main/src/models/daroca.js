const { getPool } = require("../config/db")
const { hashPassword, verifyPassword, validarSenha } = require("../middleware/auth")

async function listarProdutos() {
    const pool = getPool()
    const dados = await pool.query("SELECT * FROM daroca.produtos")
    return dados.recordset
}

async function listarClientes() {
    const pool = getPool()
    const dados = await pool.query("SELECT * FROM daroca.clientes")
    return dados.recordset
}

async function cadastrarClientes(cliente) {
    const { cpf, nome, telefone, email, senha, dataNascimento, cep, logradouro, numero, complemento, bairro, cidade, estado } = cliente
    try {
        if (!cpf || !nome || !telefone || !email || !senha) {
            return { mensagem: "Dados não foram inseridos corretamente" }
        }
        if (cpf.toString().length !== 11) {
            return { mensagem: "CPF inválido" }
        }
        if (telefone.toString().length < 9) {
            return { mensagem: "Número de telefone inválido" }
        }
        
        // Validar força da senha
        const validacaoSenha = validarSenha(senha)
        if (!validacaoSenha.isValid) {
            return { 
                mensagem: "Senha não atende aos critérios de segurança",
                errors: validacaoSenha.errors
            }
        }
        
        // Criptografar senha
        const senhaHash = await hashPassword(senha)
        
        const pool = getPool()
        const request = pool.request()
        request.input('cpf', cpf)
        request.input('nome', nome)
        request.input('telefone', telefone)
        request.input('email', email)
        request.input('senha', senhaHash)
        
        // Adicionar campos de endereço se fornecidos
        request.input('dataNascimento', dataNascimento || null)
        request.input('cep', cep || null)
        request.input('logradouro', logradouro || null)
        request.input('numero', numero || null)
        request.input('complemento', complemento || null)
        request.input('bairro', bairro || null)
        request.input('cidade', cidade || null)
        request.input('estado', estado || null)
        
        const insira = await request.query(`
            INSERT INTO daroca.clientes 
            (CPF, Nome, Telefone, Email, Senha, DataNascimento, CEP, Logradouro, Numero, Complemento, Bairro, Cidade, Estado) 
            VALUES 
            (@cpf, @nome, @telefone, @email, @senha, @dataNascimento, @cep, @logradouro, @numero, @complemento, @bairro, @cidade, @estado)
        `)
        return {
            sucesso: true,
            mensagem: "Cliente cadastrado com sucesso",
            dados: insira.recordset,
        }
    }
    catch (error) {
        return { mensagem: "Não foi possível cadastrar o cliente", erro: error.message }
    }
}

async function excluirCliente(id) {
    try {
        const pool = getPool()
        const request = pool.request()
        request.input('cpf', id)
        
        const deletar = await request.query(`DELETE FROM daroca.Clientes WHERE CPF = @cpf`)
        return {
            sucesso: true,
            mensagem: "Cliente excluído com sucesso",
            linhasAfetadas: deletar.rowsAffected[0]
        }
    }
    catch (error) {
        return { mensagem: "Não foi possível excluir o cliente", erro: error.message }
    }
}

async function atualizarCliente(id, cliente) {
    const { nome, telefone, email, senha } = cliente
    try {
        if (!nome || !telefone || !email || !senha) {
            return { mensagem: "Dados não foram inseridos corretamente" }
        }
        if (telefone.toString().length < 9) {
            return { mensagem: "Número de telefone inválido" }
        }
        
        const pool = getPool()
        const request = pool.request()
        request.input('cpf', id)
        request.input('nome', nome)
        request.input('telefone', telefone)
        request.input('email', email)
        request.input('senha', senha)
        
        const atualizar = await request.query(`UPDATE daroca.Clientes SET Nome = @nome, Telefone = @telefone, Email = @email, Senha = @senha WHERE CPF = @cpf`)
        return {
            sucesso: true,
            mensagem: "Dados atualizados com sucesso",
            linhasAfetadas: atualizar.rowsAffected[0]
        }
    }
    catch (error) {
        return { mensagem: "Não foi possível atualizar os dados do cliente", erro: error.message }
    }
}

// Login de cliente
async function loginCliente(dados) {
    const { email, senha } = dados
    try {
        if (!email || !senha) {
            return { sucesso: false, mensagem: "E-mail e senha são obrigatórios" }
        }

        const pool = getPool()
        const request = pool.request()
        request.input('email', email)
        
        // Buscar usuário pelo email (incluindo senha criptografada)
        const resultado = await request.query(`SELECT CPF, Nome, Email, Senha FROM daroca.clientes WHERE Email = @email`)
        
        if (resultado.recordset.length === 0) {
            return { sucesso: false, mensagem: "Credenciais inválidas" }
        }

        const usuario = resultado.recordset[0]
        
        // Verificar senha usando bcrypt
        const senhaValida = await verifyPassword(senha, usuario.Senha)
        
        if (!senhaValida) {
            return { sucesso: false, mensagem: "Credenciais inválidas" }
        }

        // Remover senha do retorno (segurança)
        const { Senha, ...clienteSemSenha } = usuario

        return {
            sucesso: true,
            mensagem: "Login realizado com sucesso",
            cliente: clienteSemSenha
        }
    }
    catch (error) {
        return { sucesso: false, mensagem: "Erro ao fazer login", erro: error.message }
    }
}

module.exports = { listarProdutos, cadastrarClientes, excluirCliente, atualizarCliente, loginCliente }