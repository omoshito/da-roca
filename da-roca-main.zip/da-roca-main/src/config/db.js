require('dotenv').config()
const mssql = require('mssql')

const config = {
    server: 'regulus.cotuca.unicamp.br',
    database: 'BD25560',
    user: 'BD25560',
    password: 'BD25560',
    options: {
        encrypt: false,
        trustServerCertificate: true
    }
}

let pool = null

async function conectaBD(){
    try{
        pool = await mssql.connect(config)
        console.log("Banco de dados conectado com sucesso")
        return pool
    }
    catch(error){
        console.error("Erro ao conectar no banco de dados", error);
        throw error
    }
}

function getPool() {
    if (!pool) {
        throw new Error("Banco de dados não está conectado")
    }
    return pool
}

module.exports = {mssql, conectaBD, getPool}