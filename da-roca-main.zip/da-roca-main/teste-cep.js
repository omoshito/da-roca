// ========================================
// 🧪 TESTE DAS APIs DE CEP
// ========================================
// Cole este código no Console do navegador (F12)
// para testar as APIs de CEP

console.log('🧪 Iniciando teste das APIs de CEP...\n');

// Lista de CEPs para testar
const cepsParaTestar = [
    { cep: '01310100', local: 'Av. Paulista - São Paulo/SP' },
    { cep: '20040020', local: 'Centro - Rio de Janeiro/RJ' },
    { cep: '30130010', local: 'Centro - Belo Horizonte/MG' },
    { cep: '99999999', local: 'CEP Inválido (teste de erro)' }
];

// Função de teste
async function testarCEP(cep, local) {
    console.log(`\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    console.log(`📍 Testando CEP: ${cep}`);
    console.log(`📌 Esperado: ${local}`);
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`);
    
    try {
        const resultado = await buscarEnderecoPorCEP(cep);
        
        if (resultado) {
            console.log('✅ SUCESSO!\n');
            console.log('📦 Dados retornados:');
            console.table(resultado);
        } else {
            console.log('❌ CEP não encontrado em nenhuma API\n');
        }
    } catch (error) {
        console.error('❌ ERRO:', error.message);
    }
}

// Executa os testes
async function executarTestes() {
    for (const teste of cepsParaTestar) {
        await testarCEP(teste.cep, teste.local);
        // Aguarda 1 segundo entre cada teste
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
    
    console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('🎉 Testes concluídos!');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
}

// Inicia os testes
executarTestes();

// ========================================
// 📝 TESTE INDIVIDUAL
// ========================================
// Para testar um CEP específico, use:
// buscarEnderecoPorCEP('01310100').then(console.log)
